import random

def generate_random_numbers(start, end, count):
  """Генерирует список случайных чисел из заданного диапазона без повторений.

  Args:
    start: Начальная граница диапазона (включительно).
    end: Конечная граница диапазона (исключительно).
    count: Количество случайных чисел для генерации.

  Returns:
    Список случайных чисел из заданного диапазона без повторений.
  """
  if count > (end - start + 1):
    raise ValueError("Количество чисел больше, чем размер диапазона")

  unique_numbers = set()
  while len(unique_numbers) < count:
    unique_numbers.add(random.randint(start, end-1))

  return list(unique_numbers)