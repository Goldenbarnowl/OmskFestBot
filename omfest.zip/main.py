from aiogram.utils import executor
from config import dp
from adminHendle import *
from userHundle import *
# бесконечный пойлинг для непрерывной работы бота
if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)